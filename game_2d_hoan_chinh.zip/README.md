# GAME PHIÊU LƯU 2D - CẤU TRÚC DỮ LIỆU

## File
- `index.html`: game + đăng nhập.
- `dangky.html`: trang đăng ký riêng.

## Luồng dữ liệu
1. Người chơi mở `dangky.html`.
2. Tên tài khoản + mật khẩu được kiểm tra.
3. Mật khẩu được băm SHA-256 bằng Web Crypto API trước khi lưu.
4. Dữ liệu tài khoản được lưu vào `localStorage` với khóa:
   `phieuLuu2D.accounts.v1`
5. `index.html` đọc cùng khóa để xác thực đăng nhập.
6. Phiên đăng nhập được lưu ở:
   `phieuLuu2D.session`

## Bản ghi tài khoản
```json
{
  "tennguoidung": {
    "passwordHash": "....",
    "createdAt": "2026-08-26T00:00:00.000Z",
    "level": 1,
    "score": 0
  }
}
```

## Lưu ý bảo mật
Đây là thuật toán dữ liệu phía trình duyệt cho game demo/offline.
Không nên dùng localStorage + SHA-256 làm hệ thống tài khoản thật.
Nếu đưa game lên Internet, nên chuyển tài khoản sang backend/database và dùng
Argon2id/bcrypt/scrypt cùng session/token phía máy chủ.
